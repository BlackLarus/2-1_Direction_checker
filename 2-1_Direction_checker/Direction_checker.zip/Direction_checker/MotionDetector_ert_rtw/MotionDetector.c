/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: MotionDetector.c
 *
 * Code generated for Simulink model 'MotionDetector'.
 *
 * Model version                  : 1.3
 * Simulink Coder version         : 9.4 (R2020b) 29-Jul-2020
 * C/C++ source code generated on : Fri May 28 23:18:15 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "MotionDetector.h"
#include "MotionDetector_private.h"

/* Named constants for Chart: '<Root>/Chart' */
#define MotionDetector_IN_Idle         (1UL)
#define MotionDetector_IN_L_Entering   (2UL)
#define MotionDetector_IN_R_Entering1  (3UL)

/* Block signals (default storage) */
B_MotionDetector_T MotionDetector_B;

/* Block states (default storage) */
DW_MotionDetector_T MotionDetector_DW;

/* Real-time model */
static RT_MODEL_MotionDetector_T MotionDetector_M_;
RT_MODEL_MotionDetector_T *const MotionDetector_M = &MotionDetector_M_;

/* Model step function */
void MotionDetector_step(void)
{
  uint32_T duration;
  boolean_T guard1 = false;
  boolean_T guard2 = false;
  boolean_T guard3 = false;
  boolean_T guard4 = false;
  boolean_T rtb_Switch1;
  boolean_T rtb_u;

  /* Reset subsysRan breadcrumbs */
  srClearBC(MotionDetector_DW.Right_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(MotionDetector_DW.Left_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(MotionDetector_DW.Neither_SubsysRanBC);

  /* MATLABSystem: '<Root>/Right Sensor' */
  if (MotionDetector_DW.obj.TunablePropsChanged) {
    MotionDetector_DW.obj.TunablePropsChanged = false;
  }

  MW_UltrasonicRead(&duration, 1, 2, 3, 10);

  /* Gain: '<Root>/Gain' incorporates:
   *  MATLABSystem: '<Root>/Right Sensor'
   */
  MotionDetector_B.Gain = (real_T)duration * 0.000343 / 2.0 *
    MotionDetector_P.Gain_Gain;

  /* Switch: '<Root>/. ' incorporates:
   *  Constant: '<Root>/R_disFalse'
   *  Constant: '<Root>/R_disTrue'
   */
  if (MotionDetector_B.Gain > MotionDetector_P._Threshold) {
    rtb_u = MotionDetector_P.R_disFalse_Value;
  } else {
    rtb_u = MotionDetector_P.R_disTrue_Value;
  }

  /* End of Switch: '<Root>/. ' */

  /* MATLABSystem: '<Root>/Left Sensor' */
  if (MotionDetector_DW.obj_m.TunablePropsChanged) {
    MotionDetector_DW.obj_m.TunablePropsChanged = false;
  }

  MW_UltrasonicRead(&duration, 1, 4, 5, 10);

  /* Gain: '<Root>/Gain1' incorporates:
   *  MATLABSystem: '<Root>/Left Sensor'
   */
  MotionDetector_B.Gain1 = (real_T)duration * 0.000343 / 2.0 *
    MotionDetector_P.Gain1_Gain;

  /* Switch: '<Root>/Switch1' incorporates:
   *  Constant: '<Root>/L_disFalse'
   *  Constant: '<Root>/L_disTrue'
   */
  if (MotionDetector_B.Gain1 > MotionDetector_P.Switch1_Threshold) {
    rtb_Switch1 = MotionDetector_P.L_disFalse_Value;
  } else {
    rtb_Switch1 = MotionDetector_P.L_disTrue_Value;
  }

  /* End of Switch: '<Root>/Switch1' */

  /* If: '<Root>/If' */
  if (rtb_u && (!rtb_Switch1)) {
    /* Outputs for IfAction SubSystem: '<Root>/Right ' incorporates:
     *  ActionPort: '<S4>/Action Port'
     */
    /* Merge: '<Root>/Merge' incorporates:
     *  Constant: '<Root>/Right'
     *  Inport: '<S4>/In1'
     */
    MotionDetector_B.Merge = MotionDetector_P.Right_Value;

    /* End of Outputs for SubSystem: '<Root>/Right ' */

    /* Update for IfAction SubSystem: '<Root>/Right ' incorporates:
     *  ActionPort: '<S4>/Action Port'
     */
    /* Update for If: '<Root>/If' */
    srUpdateBC(MotionDetector_DW.Right_SubsysRanBC);

    /* End of Update for SubSystem: '<Root>/Right ' */
  } else if ((!rtb_u) && rtb_Switch1) {
    /* Outputs for IfAction SubSystem: '<Root>/Left ' incorporates:
     *  ActionPort: '<S2>/Action Port'
     */
    /* Merge: '<Root>/Merge' incorporates:
     *  Constant: '<Root>/Left'
     *  Inport: '<S2>/In1'
     */
    MotionDetector_B.Merge = MotionDetector_P.Left_Value;

    /* End of Outputs for SubSystem: '<Root>/Left ' */

    /* Update for IfAction SubSystem: '<Root>/Left ' incorporates:
     *  ActionPort: '<S2>/Action Port'
     */
    /* Update for If: '<Root>/If' */
    srUpdateBC(MotionDetector_DW.Left_SubsysRanBC);

    /* End of Update for SubSystem: '<Root>/Left ' */
  } else {
    /* Outputs for IfAction SubSystem: '<Root>/Neither' incorporates:
     *  ActionPort: '<S3>/Action Port'
     */
    /* Merge: '<Root>/Merge' incorporates:
     *  Constant: '<Root>/Constant2'
     *  Inport: '<S3>/In1'
     */
    MotionDetector_B.Merge = MotionDetector_P.Constant2_Value;

    /* End of Outputs for SubSystem: '<Root>/Neither' */

    /* Update for IfAction SubSystem: '<Root>/Neither' incorporates:
     *  ActionPort: '<S3>/Action Port'
     */
    /* Update for If: '<Root>/If' */
    srUpdateBC(MotionDetector_DW.Neither_SubsysRanBC);

    /* End of Update for SubSystem: '<Root>/Neither' */
  }

  /* End of If: '<Root>/If' */
  /* DigitalClock: '<Root>/Digital Clock' */
  MotionDetector_B.DigitalClock = MotionDetector_M->Timing.taskTime0;

  /* Chart: '<Root>/Chart' */
  if (MotionDetector_DW.temporalCounter_i1 < 63U) {
    MotionDetector_DW.temporalCounter_i1++;
  }

  if (MotionDetector_DW.is_active_c3_MotionDetector == 0U) {
    MotionDetector_DW.is_active_c3_MotionDetector = 1U;
    MotionDetector_DW.is_c3_MotionDetector = MotionDetector_IN_Idle;
    switch (MotionDetector_B.Merge) {
     case -1:
      MotionDetector_DW.entering = -1;
      break;

     case 1:
      MotionDetector_DW.entering = 1;
      break;

     default:
      MotionDetector_DW.entering = 0;
      break;
    }
  } else {
    guard1 = false;
    guard2 = false;
    guard3 = false;
    guard4 = false;
    switch (MotionDetector_DW.is_c3_MotionDetector) {
     case MotionDetector_IN_Idle:
      switch (MotionDetector_DW.entering) {
       case -1:
        MotionDetector_DW.time_f = MotionDetector_B.DigitalClock;
        MotionDetector_DW.is_c3_MotionDetector = MotionDetector_IN_L_Entering;
        MotionDetector_DW.temporalCounter_i1 = 0U;
        if (MotionDetector_B.Merge == 1) {
          MotionDetector_B.OUT_T = MotionDetector_B.DigitalClock -
            MotionDetector_DW.time_f;
          MotionDetector_B.OUT = 1.0;
        }
        break;

       case 1:
        MotionDetector_DW.time_f = MotionDetector_B.DigitalClock;
        MotionDetector_DW.is_c3_MotionDetector = MotionDetector_IN_R_Entering1;
        MotionDetector_DW.temporalCounter_i1 = 0U;
        if (MotionDetector_B.Merge == -1) {
          MotionDetector_B.OUT_T = MotionDetector_B.DigitalClock -
            MotionDetector_DW.time_f;
          MotionDetector_B.OUT = -1.0;
        }
        break;

       default:
        switch (MotionDetector_B.Merge) {
         case -1:
          MotionDetector_DW.entering = -1;
          break;

         case 1:
          MotionDetector_DW.entering = 1;
          break;

         default:
          MotionDetector_DW.entering = 0;
          break;
        }
        break;
      }
      break;

     case MotionDetector_IN_L_Entering:
      if (MotionDetector_B.OUT == 1.0) {
        MotionDetector_DW.entering = 0;
        MotionDetector_B.OUT_T = 0.0;
        if (MotionDetector_DW.temporalCounter_i1 >= 5U) {
          MotionDetector_B.OUT = 0.0;
          guard3 = true;
        } else {
          guard4 = true;
        }
      } else {
        guard4 = true;
      }
      break;

     default:
      /* case IN_R_Entering1: */
      if (MotionDetector_DW.temporalCounter_i1 >= 50U) {
        guard2 = true;
      } else if (MotionDetector_B.OUT == -1.0) {
        MotionDetector_DW.entering = 0;
        MotionDetector_B.OUT_T = 0.0;
        if (MotionDetector_DW.temporalCounter_i1 >= 5U) {
          MotionDetector_B.OUT = 0.0;
          guard2 = true;
        } else {
          guard1 = true;
        }
      } else {
        guard1 = true;
      }
      break;
    }

    if (guard4) {
      if (MotionDetector_DW.temporalCounter_i1 >= 50U) {
        guard3 = true;
      } else {
        if (MotionDetector_B.Merge == 1) {
          MotionDetector_B.OUT_T = MotionDetector_B.DigitalClock -
            MotionDetector_DW.time_f;
          MotionDetector_B.OUT = 1.0;
        }
      }
    }

    if (guard3) {
      MotionDetector_DW.is_c3_MotionDetector = MotionDetector_IN_Idle;
      switch (MotionDetector_B.Merge) {
       case -1:
        MotionDetector_DW.entering = -1;
        break;

       case 1:
        MotionDetector_DW.entering = 1;
        break;

       default:
        MotionDetector_DW.entering = 0;
        break;
      }
    }

    if (guard2) {
      MotionDetector_DW.is_c3_MotionDetector = MotionDetector_IN_Idle;
      switch (MotionDetector_B.Merge) {
       case -1:
        MotionDetector_DW.entering = -1;
        break;

       case 1:
        MotionDetector_DW.entering = 1;
        break;

       default:
        MotionDetector_DW.entering = 0;
        break;
      }
    }

    if (guard1) {
      if (MotionDetector_B.Merge == -1) {
        MotionDetector_B.OUT_T = MotionDetector_B.DigitalClock -
          MotionDetector_DW.time_f;
        MotionDetector_B.OUT = -1.0;
      }
    }
  }

  /* End of Chart: '<Root>/Chart' */

  /* Switch: '<Root>/Switch2' */
  if (MotionDetector_B.OUT_T > MotionDetector_P.Switch2_Threshold) {
    /* Switch: '<Root>/Switch2' incorporates:
     *  Constant: '<Root>/Constant'
     *  Product: '<Root>/Divide'
     */
    MotionDetector_B.Switch2 = MotionDetector_P.Constant_Value /
      MotionDetector_B.OUT_T;
  } else {
    /* Switch: '<Root>/Switch2' incorporates:
     *  Constant: '<Root>/Constant1'
     */
    MotionDetector_B.Switch2 = MotionDetector_P.Constant1_Value;
  }

  /* End of Switch: '<Root>/Switch2' */

  /* External mode */
  rtExtModeUploadCheckTrigger(1);

  {                                    /* Sample time: [0.02s, 0.0s] */
    rtExtModeUpload(0, (real_T)MotionDetector_M->Timing.taskTime0);
  }

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.02s, 0.0s] */
    if ((rtmGetTFinal(MotionDetector_M)!=-1) &&
        !((rtmGetTFinal(MotionDetector_M)-MotionDetector_M->Timing.taskTime0) >
          MotionDetector_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(MotionDetector_M, "Simulation finished");
    }

    if (rtmGetStopRequested(MotionDetector_M)) {
      rtmSetErrorStatus(MotionDetector_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  MotionDetector_M->Timing.taskTime0 =
    ((time_T)(++MotionDetector_M->Timing.clockTick0)) *
    MotionDetector_M->Timing.stepSize0;
}

/* Model initialize function */
void MotionDetector_initialize(void)
{
  /* Registration code */
  rtmSetTFinal(MotionDetector_M, -1);
  MotionDetector_M->Timing.stepSize0 = 0.02;

  /* External mode info */
  MotionDetector_M->Sizes.checksums[0] = (3570190038U);
  MotionDetector_M->Sizes.checksums[1] = (1904339611U);
  MotionDetector_M->Sizes.checksums[2] = (2669945434U);
  MotionDetector_M->Sizes.checksums[3] = (3484236867U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[13];
    MotionDetector_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = (sysRanDType *)&MotionDetector_DW.Left_SubsysRanBC;
    systemRan[3] = &rtAlwaysEnabled;
    systemRan[4] = (sysRanDType *)&MotionDetector_DW.Neither_SubsysRanBC;
    systemRan[5] = (sysRanDType *)&MotionDetector_DW.Right_SubsysRanBC;
    systemRan[6] = &rtAlwaysEnabled;
    systemRan[7] = &rtAlwaysEnabled;
    systemRan[8] = &rtAlwaysEnabled;
    systemRan[9] = &rtAlwaysEnabled;
    systemRan[10] = &rtAlwaysEnabled;
    systemRan[11] = &rtAlwaysEnabled;
    systemRan[12] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(MotionDetector_M->extModeInfo,
      &MotionDetector_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(MotionDetector_M->extModeInfo,
                        MotionDetector_M->Sizes.checksums);
    rteiSetTPtr(MotionDetector_M->extModeInfo, rtmGetTPtr(MotionDetector_M));
  }

  /* Start for MATLABSystem: '<Root>/Right Sensor' */
  MotionDetector_DW.obj.isInitialized = 1L;
  MW_UltrasonicSetup(2, 3);
  MotionDetector_DW.obj.TunablePropsChanged = false;

  /* Start for MATLABSystem: '<Root>/Left Sensor' */
  MotionDetector_DW.obj_m.isInitialized = 1L;
  MW_UltrasonicSetup(4, 5);
  MotionDetector_DW.obj_m.TunablePropsChanged = false;
}

/* Model terminate function */
void MotionDetector_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
