/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: MotionDetector_types.h
 *
 * Code generated for Simulink model 'MotionDetector'.
 *
 * Model version                  : 1.3
 * Simulink Coder version         : 9.4 (R2020b) 29-Jul-2020
 * C/C++ source code generated on : Fri May 28 23:18:15 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_MotionDetector_types_h_
#define RTW_HEADER_MotionDetector_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"

/* Model Code Variants */
#ifndef struct_tag_Hh0aNiR2hzWltgFb36YvQD
#define struct_tag_Hh0aNiR2hzWltgFb36YvQD

struct tag_Hh0aNiR2hzWltgFb36YvQD
{
  int32_T isInitialized;
  boolean_T TunablePropsChanged;
};

#endif                                 /*struct_tag_Hh0aNiR2hzWltgFb36YvQD*/

#ifndef typedef_codertarget_arduinobase_inter_T
#define typedef_codertarget_arduinobase_inter_T

typedef struct tag_Hh0aNiR2hzWltgFb36YvQD codertarget_arduinobase_inter_T;

#endif                               /*typedef_codertarget_arduinobase_inter_T*/

/* Parameters (default storage) */
typedef struct P_MotionDetector_T_ P_MotionDetector_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_MotionDetector_T RT_MODEL_MotionDetector_T;

#endif                                 /* RTW_HEADER_MotionDetector_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
