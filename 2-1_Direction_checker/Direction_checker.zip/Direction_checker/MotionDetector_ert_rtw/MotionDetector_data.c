/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: MotionDetector_data.c
 *
 * Code generated for Simulink model 'MotionDetector'.
 *
 * Model version                  : 1.3
 * Simulink Coder version         : 9.4 (R2020b) 29-Jul-2020
 * C/C++ source code generated on : Fri May 28 23:18:15 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "MotionDetector.h"
#include "MotionDetector_private.h"

/* Block parameters (default storage) */
P_MotionDetector_T MotionDetector_P = {
  /* Expression: 0.1
   * Referenced by: '<Root>/Constant'
   */
  0.1,

  /* Expression: 0
   * Referenced by: '<Root>/Constant1'
   */
  0.0,

  /* Expression: 100
   * Referenced by: '<Root>/Gain'
   */
  100.0,

  /* Expression: 15
   * Referenced by: '<Root>/. '
   */
  15.0,

  /* Expression: 100
   * Referenced by: '<Root>/Gain1'
   */
  100.0,

  /* Expression: 15
   * Referenced by: '<Root>/Switch1'
   */
  15.0,

  /* Expression: 0
   * Referenced by: '<Root>/Switch2'
   */
  0.0,

  /* Expression: false
   * Referenced by: '<Root>/R_disFalse'
   */
  0,

  /* Expression: true
   * Referenced by: '<Root>/R_disTrue'
   */
  1,

  /* Expression: false
   * Referenced by: '<Root>/L_disFalse'
   */
  0,

  /* Expression: true
   * Referenced by: '<Root>/L_disTrue'
   */
  1,

  /* Computed Parameter: Right_Value
   * Referenced by: '<Root>/Right'
   */
  1,

  /* Computed Parameter: Constant2_Value
   * Referenced by: '<Root>/Constant2'
   */
  0,

  /* Computed Parameter: Left_Value
   * Referenced by: '<Root>/Left'
   */
  -1
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
